import javax.vecmath.Vector3f;


public class Camera {
	Vector3f position, cameraView;
	
	public Camera(Vector3f cameraView){
		this.cameraView = cameraView;
	}
	
	
}
